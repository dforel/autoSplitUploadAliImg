# 自动裁切视频并且上传。

python版本：python3.6
ffmpeg版本：4.1.3

### 安装步骤【window版】

    1.下载ffmpeg，将ffmpeg放到windows的path中。

    2.  pip install flask 
        pip install flask_wtf 
        pip install requests  

    3.python main.py 启动

### 安装步骤【centos】

    1.yum install ffmpeg;
        或者 自己编译参考文章：https://www.cnblogs.com/wanglao/p/11162432.html


    2.  pip install flask 
        pip install flask_wtf 
        pip install requests  

    3.python main.py 启动